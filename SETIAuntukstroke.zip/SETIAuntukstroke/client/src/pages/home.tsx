import { Heart, Shield, ShieldCheck, UserCheck, Phone, Lock, Ambulance, Hospital } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import EmergencyBanner from "@/components/emergency-banner";
import UploadSection from "@/components/upload-section";
import ComparisonSection from "@/components/comparison-section";
import SetiaMethod from "@/components/fast-method";
import EducationalContent from "@/components/educational-content";

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-medical-blue text-white py-4 shadow-lg">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Heart className="h-8 w-8" />
              <h1 className="text-xl md:text-2xl font-bold">Galeri Stroke</h1>
            </div>
            <div className="text-right text-sm opacity-90">
              <p>Deteksi Dini</p>
              <p className="text-xs">Selamatkan Nyawa</p>
            </div>
          </div>
        </div>
      </header>

      <EmergencyBanner />

      <main className="container mx-auto px-4 py-6 space-y-8">
        {/* Intro Section */}
        <Card className="border border-gray-200">
          <CardContent className="p-6">
            <div className="text-center mb-6">
              <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-3">Cek Gejala Stroke pada Wajah</h2>
              <p className="text-gray-600 leading-relaxed max-w-2xl mx-auto">
                Unggah foto wajah Anda saat tersenyum normal, lalu bandingkan dengan contoh gejala stroke di bawah. 
                <span className="font-semibold text-medical-blue"> Foto tidak disimpan</span> dan hanya ditampilkan di perangkat Anda.
              </p>
            </div>
            
            <div className="flex items-center justify-center space-x-4 text-sm text-gray-500 bg-blue-50 p-4 rounded-lg">
              <Shield className="text-medical-blue h-5 w-5" />
              <span>Privasi Terjamin • Tidak Ada Penyimpanan • Hanya Di Perangkat Anda</span>
            </div>
          </CardContent>
        </Card>

        <UploadSection />
        <ComparisonSection />
        <SetiaMethod />
        <EducationalContent />

        {/* Disclaimer Section */}
        <Card className="bg-gray-100 border border-gray-300">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
              <ShieldCheck className="text-gray-600 mr-2 h-5 w-5" />
              Penting untuk Diketahui
            </h3>
            
            <div className="space-y-4 text-sm text-gray-700">
              <div className="flex items-start space-x-3">
                <Shield className="text-warning-orange mt-1 h-4 w-4 flex-shrink-0" />
                <p><strong>Bukan Pengganti Diagnosis Medis:</strong> Aplikasi ini hanya untuk edukasi dan tidak menggantikan diagnosis atau saran medis profesional.</p>
              </div>
              
              <div className="flex items-start space-x-3">
                <UserCheck className="text-medical-blue mt-1 h-4 w-4 flex-shrink-0" />
                <p><strong>Konsultasi Dokter:</strong> Selalu konsultasikan dengan tenaga medis untuk diagnosis yang akurat dan penanganan yang tepat.</p>
              </div>
              
              <div className="flex items-start space-x-3">
                <Phone className="text-emergency-red mt-1 h-4 w-4 flex-shrink-0" />
                <p><strong>Situasi Darurat:</strong> Jika Anda atau orang lain menunjukkan gejala stroke, segera hubungi nomor darurat 119 atau 112.</p>
              </div>
              
              <div className="flex items-start space-x-3">
                <Lock className="text-success-green mt-1 h-4 w-4 flex-shrink-0" />
                <p><strong>Privasi Terjamin:</strong> Semua foto diproses di perangkat Anda dan tidak dikirim ke server manapun.</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Contacts */}
        <Card className="bg-emergency-red text-white shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-xl font-bold mb-4 text-center">Kontak Darurat</h3>
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div className="bg-white bg-opacity-20 rounded-lg p-4">
                <Ambulance className="text-2xl mb-2 mx-auto h-8 w-8" />
                <h4 className="font-semibold">Ambulans</h4>
                <p className="text-xl font-bold">119</p>
              </div>
              <div className="bg-white bg-opacity-20 rounded-lg p-4">
                <Phone className="text-2xl mb-2 mx-auto h-8 w-8" />
                <h4 className="font-semibold">Darurat Umum</h4>
                <p className="text-xl font-bold">112</p>
              </div>
              <div className="bg-white bg-opacity-20 rounded-lg p-4">
                <Hospital className="text-2xl mb-2 mx-auto h-8 w-8" />
                <h4 className="font-semibold">RS Terdekat</h4>
                <p className="text-sm">Cari di Google Maps</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-8 mt-12">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-4">
            <h4 className="font-semibold text-lg mb-2">Galeri Stroke</h4>
            <p className="text-gray-300 text-sm">Edukasi dan Deteksi Dini Stroke</p>
          </div>
          <div className="border-t border-gray-700 pt-4">
            <p className="text-xs text-gray-400">
              © 2024 Galeri Stroke. Untuk tujuan edukasi. Tidak menggantikan saran medis profesional.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { Smile, Hand, MessageCircle, Ambulance, Volume2 } from "lucide-react";
import strokeAudio from "@assets/cara mengobati stroke ringan susah bicara, Alami Stroke Gangguan Berkomunikasi tutorial pengobatan_1750687265690.mp3";

export default function SetiaMethod() {
  return (
    <section 
      className="rounded-2xl shadow-lg p-8"
      style={{ backgroundColor: '#FFF3E0' }}
    >
      <h2 className="text-3xl font-bold mb-4 text-center" style={{ color: '#D32F2F' }}>
        Kenali Stroke dengan Metode <span style={{ color: '#C62828' }}>SETIA</span>
      </h2>
      <p className="text-center mb-8 text-gray-700">
        Metode <strong>SETIA</strong> adalah panduan cepat mengenali gejala awal stroke secara mandiri.
      </p>
      
      <div className="space-y-6">
        {/* SE - Senyum */}
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <Smile className="h-8 w-8" style={{ color: '#E64A19' }} />
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2" style={{ color: '#E64A19' }}>
                SE – Senyum
              </h3>
              <p className="text-gray-700">
                Minta orang tersenyum. Apakah wajah tampak tidak simetris? Jika salah satu sisi mencong atau tidak bergerak, ini bisa jadi tanda stroke.
              </p>
            </div>
          </div>
        </div>

        {/* T - Tangan */}
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <Hand className="h-8 w-8" style={{ color: '#E64A19' }} />
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2" style={{ color: '#E64A19' }}>
                T – Tangan
              </h3>
              <p className="text-gray-700">
                Minta orang mengangkat kedua tangan. Jika satu tangan tampak lemas atau turun, waspadai kemungkinan stroke.
              </p>
            </div>
          </div>
        </div>

        {/* I - Intonasi */}
        <div className="bg-white rounded-lg p-6 shadow-sm">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <MessageCircle className="h-8 w-8" style={{ color: '#E64A19' }} />
            </div>
            <div className="flex-grow">
              <h3 className="text-xl font-bold mb-2" style={{ color: '#E64A19' }}>
                I – Intonasi
              </h3>
              <p className="text-gray-700 mb-4">
                Minta orang mengucapkan kalimat sederhana. Perhatikan apakah bicaranya pelo, tidak jelas, atau sulit dimengerti.
              </p>
              
              <div className="bg-orange-50 p-4 rounded-lg">
                <p className="font-semibold text-gray-700 mb-3 flex items-center">
                  <Volume2 className="mr-2 h-5 w-5" style={{ color: '#E64A19' }} />
                  Dengarkan contoh suara penderita stroke:
                </p>
                <audio controls className="w-full max-w-md">
                  <source src={strokeAudio} type="audio/mpeg" />
                  Browser kamu tidak mendukung pemutar audio.
                </audio>
              </div>
            </div>
          </div>
        </div>

        {/* A - Ambulans */}
        <div className="bg-white rounded-lg p-6 shadow-sm border-2 border-red-200">
          <div className="flex items-start space-x-4">
            <div className="flex-shrink-0">
              <Ambulance className="h-8 w-8" style={{ color: '#E64A19' }} />
            </div>
            <div>
              <h3 className="text-xl font-bold mb-2" style={{ color: '#E64A19' }}>
                A – Ambulans
              </h3>
              <p className="text-gray-700">
                Jika terdapat salah satu tanda di atas, <strong>SEGERA hubungi ambulans 119</strong> atau bawa ke IGD rumah sakit terdekat. <strong>Waktu adalah otak!</strong>
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

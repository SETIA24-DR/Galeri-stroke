import { useState, useRef } from "react";
import { Camera, Upload, Image, Info, Smile } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function UploadSection() {
  const [preview, setPreview] = useState<string | null>(null);
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    // Validate file type
    if (!file.type.startsWith('image/')) {
      alert('Mohon pilih file gambar (JPG, PNG, GIF)');
      return;
    }
    
    // Validate file size (10MB max)
    if (file.size > 10 * 1024 * 1024) {
      alert('Ukuran file terlalu besar. Maksimal 10MB.');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleFileSelect(files[0]);
    }
  };

  const handleButtonClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <Card className="p-6 border border-gray-200">
      <h3 className="text-xl font-semibold text-gray-800 mb-4 flex items-center">
        <Camera className="text-medical-blue mr-3" />
        Unggah Foto Wajah Anda
      </h3>
      
      <div className="grid md:grid-cols-2 gap-6 items-start">
        {/* Upload Area */}
        <div className="space-y-4">
          <div 
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors duration-200 cursor-pointer ${
              isDragOver 
                ? 'border-medical-blue bg-blue-50' 
                : preview 
                  ? 'border-success-green bg-green-50' 
                  : 'border-gray-300 hover:border-medical-blue'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={handleButtonClick}
          >
            <input 
              type="file" 
              accept="image/*" 
              capture="user"
              ref={fileInputRef}
              className="hidden" 
              onChange={handleFileChange}
            />
            <Upload className="text-4xl text-gray-400 mb-4 mx-auto h-12 w-12" />
            <span className="text-lg font-medium text-gray-700 block mb-2">Klik untuk unggah foto</span>
            <span className="text-sm text-gray-500 block mb-4">atau ambil foto langsung</span>
            <Button className="bg-medical-blue text-white hover:bg-blue-700">
              <Camera className="mr-2 h-4 w-4" />
              Pilih Foto
            </Button>
          </div>
          
          <div className="text-xs text-gray-500 space-y-1">
            <p className="flex items-center">
              <Info className="mr-1 h-3 w-3" />
              Format: JPG, PNG, GIF (maksimal 10MB)
            </p>
            <p className="flex items-center">
              <Smile className="mr-1 h-3 w-3" />
              Pastikan wajah terlihat jelas dan tersenyum
            </p>
          </div>
        </div>
        
        {/* Preview Area */}
        <div className="space-y-4">
          <h4 className="font-medium text-gray-700">Preview Foto Anda:</h4>
          <div className="border border-gray-200 rounded-xl p-4 bg-gray-50 min-h-[250px] flex items-center justify-center">
            {preview ? (
              <img 
                src={preview} 
                alt="Preview foto pengguna" 
                className="max-w-full h-auto rounded-lg shadow-md max-h-[300px]"
              />
            ) : (
              <div className="text-center text-gray-400">
                <Image className="text-3xl mb-3 mx-auto h-12 w-12" />
                <p>Foto akan muncul di sini</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}

import { Info, Clock, CheckSquare, ChevronRight } from "lucide-react";
import { Card } from "@/components/ui/card";

export default function EducationalContent() {
  return (
    <Card className="p-6 border border-gray-200">
      <h3 className="text-xl font-semibold text-gray-800 mb-6">Informasi Penting tentang Stroke</h3>
      
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h4 className="font-semibold text-gray-700 mb-3 flex items-center">
            <Info className="text-medical-blue mr-2 h-5 w-5" />
            Apa itu Stroke?
          </h4>
          <p className="text-gray-600 text-sm leading-relaxed mb-4">
            Stroke terjadi ketika aliran darah ke bagian otak terhenti, menyebabkan sel-sel otak rusak atau mati. 
            Deteksi dini dan penanganan cepat sangat penting untuk menyelamatkan nyawa dan mencegah kerusakan permanen.
          </p>
          
          <h4 className="font-semibold text-gray-700 mb-3 flex items-center">
            <Clock className="text-warning-orange mr-2 h-5 w-5" />
            Mengapa Waktu Penting?
          </h4>
          <p className="text-gray-600 text-sm leading-relaxed">
            Setiap menit yang berlalu, jutaan sel otak bisa rusak. Penanganan dalam 3-4.5 jam pertama 
            dapat mencegah kerusakan otak yang lebih parah.
          </p>
        </div>
        
        <div>
          <h4 className="font-semibold text-gray-700 mb-3 flex items-center">
            <CheckSquare className="text-success-green mr-2 h-5 w-5" />
            Gejala Stroke Lainnya
          </h4>
          <ul className="text-sm text-gray-600 space-y-2">
            <li className="flex items-start">
              <ChevronRight className="text-gray-400 mr-2 mt-1 h-3 w-3 flex-shrink-0" />
              Mendadak bingung atau kesulitan berbicara
            </li>
            <li className="flex items-start">
              <ChevronRight className="text-gray-400 mr-2 mt-1 h-3 w-3 flex-shrink-0" />
              Mendadak sulit melihat dengan satu atau kedua mata
            </li>
            <li className="flex items-start">
              <ChevronRight className="text-gray-400 mr-2 mt-1 h-3 w-3 flex-shrink-0" />
              Mendadak sulit berjalan atau kehilangan keseimbangan
            </li>
            <li className="flex items-start">
              <ChevronRight className="text-gray-400 mr-2 mt-1 h-3 w-3 flex-shrink-0" />
              Sakit kepala hebat tanpa sebab yang jelas
            </li>
            <li className="flex items-start">
              <ChevronRight className="text-gray-400 mr-2 mt-1 h-3 w-3 flex-shrink-0" />
              Mual, muntah, atau demam
            </li>
          </ul>
        </div>
      </div>
    </Card>
  );
}

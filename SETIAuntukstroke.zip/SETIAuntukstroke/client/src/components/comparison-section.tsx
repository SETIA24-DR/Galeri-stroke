import { Search, CheckCircle, TriangleAlert, Smile, Eye, ArrowLeftRight, Frown, EyeOff, AlertTriangle, Lightbulb } from "lucide-react";
import { Card } from "@/components/ui/card";
import strokeFaceImage from "@assets/images_1750681903186.jpg";

export default function ComparisonSection() {
  return (
    <Card className="p-6 border border-gray-200">
      <h3 className="text-xl font-semibold text-gray-800 mb-6 flex items-center">
        <Search className="text-medical-blue mr-3" />
        Bandingkan dengan Gejala Stroke
      </h3>
      
      <div className="grid md:grid-cols-2 gap-8">
        {/* Normal Face */}
        <div className="text-center">
          <h4 className="font-semibold text-success-green mb-4 text-lg flex items-center justify-center">
            <CheckCircle className="mr-2" />
            Wajah Normal
          </h4>
          <img 
            src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=400" 
            alt="Contoh wajah normal dengan senyum simetris" 
            className="rounded-xl shadow-md w-full max-w-[250px] mx-auto mb-4 border-2 border-success-green"
          />
          <div className="text-sm text-gray-600 space-y-1">
            <p className="flex items-center justify-center">
              <Smile className="text-success-green mr-2 h-4 w-4" />
              Senyum simetris
            </p>
            <p className="flex items-center justify-center">
              <Eye className="text-success-green mr-2 h-4 w-4" />
              Mata sejajar
            </p>
            <p className="flex items-center justify-center">
              <ArrowLeftRight className="text-success-green mr-2 h-4 w-4" />
              Wajah proporsional
            </p>
          </div>
        </div>
        
        {/* Stroke Face */}
        <div className="text-center">
          <h4 className="font-semibold text-emergency-red mb-4 text-lg flex items-center justify-center">
            <TriangleAlert className="mr-2" />
            Gejala Stroke
          </h4>
          <img 
            src={strokeFaceImage} 
            alt="Ilustrasi medis gejala stroke pada wajah - menunjukkan kelumpuhan wajah satu sisi" 
            className="rounded-xl shadow-md w-full max-w-[250px] mx-auto mb-4 border-2 border-emergency-red"
          />
          <div className="text-sm text-gray-600 space-y-1">
            <p className="flex items-center justify-center">
              <Frown className="text-emergency-red mr-2 h-4 w-4" />
              Senyum miring/turun
            </p>
            <p className="flex items-center justify-center">
              <EyeOff className="text-emergency-red mr-2 h-4 w-4" />
              Mata tidak simetris
            </p>
            <p className="flex items-center justify-center">
              <AlertTriangle className="text-emergency-red mr-2 h-4 w-4" />
              Wajah terkulai
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-6 p-4 bg-yellow-50 border border-warning-orange rounded-lg">
        <p className="text-sm text-gray-700 flex items-start">
          <Lightbulb className="text-warning-orange mr-2 mt-0.5 h-4 w-4 flex-shrink-0" />
          <span>
            <strong>Tips:</strong> Minta orang tersebut tersenyum atau tunjukkan gigi. Jika satu sisi wajah terkulai atau senyumnya tidak rata, ini bisa menjadi tanda stroke.
          </span>
        </p>
      </div>
    </Card>
  );
}

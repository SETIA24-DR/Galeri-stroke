import { AlertTriangle, Phone } from "lucide-react";

export default function EmergencyBanner() {
  return (
    <div className="bg-emergency-red text-white py-3">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center space-x-3 text-sm md:text-base">
          <AlertTriangle className="h-5 w-5" />
          <span className="font-semibold">DARURAT STROKE:</span>
          <span>Hubungi 119 atau 112 segera!</span>
          <Phone className="h-4 w-4" />
        </div>
      </div>
    </div>
  );
}
